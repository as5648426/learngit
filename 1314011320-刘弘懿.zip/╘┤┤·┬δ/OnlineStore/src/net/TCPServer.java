package net;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TCPServer implements Runnable {
	
	private static volatile boolean flag = true;
	private int port;
	private static ServerSocket server;
	
	
	private static ExecutorService executorService = Executors.newCachedThreadPool();
	public TCPServer(int port){
		this.port = port;
		try {
			server = new ServerSocket(port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		while( !executorService.isShutdown() ){
			try {
				Socket client = server.accept();
				executorService.execute( new Talk(client) );
				
			} catch (IOException e) {
			}
		}
	}
	
	public static void start(int port){
		Thread tcpServer = new Thread( new TCPServer(port) );
		tcpServer.setDaemon( true );
		tcpServer.start();
	}
//	
//	public static void stop(){
//		executorService.shutdown();
//		flag = false;
//		Set<Map.Entry<String, Socket>> entries = Talk.getClients().entrySet();
//		for(Map.Entry<String, Socket> entry : entries){
//			try {
//				entry.getValue().close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		if( server != null && ! server.isClosed() ){
//			try {
//				server.close();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//	}

}