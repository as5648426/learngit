package net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

public class TCPClient {
	
	private Socket server = null;
	
	public TCPClient(){
		try {
			InetAddress ia=null;
				ia=ia.getLocalHost();
				
				String localname=ia.getHostName();
				String localip=ia.getHostAddress();
//				System.out.println("本机名称是："+ localname);
//				System.out.println("本机的ip是 ："+localip);
				server = new Socket(localip, 8888);
			} catch (Exception e) {
				e.printStackTrace();
				
		}
	}
	
	public String send( String msg ){
		
		PrintWriter writer = null;
		BufferedReader reader = null;
		try {
			writer = new PrintWriter(server.getOutputStream(), true);
			writer.println( msg );
			reader = new BufferedReader(new InputStreamReader(server.getInputStream()));
			String result = reader.readLine(); //收到服务端消息
			return result;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			
				try {
					if( writer != null) writer.close();
					if( server != null && server.isConnected() )
						server.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return "error";
	}
	

}