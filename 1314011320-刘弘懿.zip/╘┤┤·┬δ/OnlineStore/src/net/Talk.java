package net;


	
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import cn.edu.nuc.onlinestore.model.Cart;
import cn.edu.nuc.onlinestore.model.Goods;
import cn.edu.nuc.onlinestore.model.Login;
import cn.edu.nuc.onlinestore.model.Register;
import cn.edu.nuc.onlinestore.model.Search;
import cn.edu.nuc.onlinestore.model.Show;
import operater.ObjectStream;
import person.Customer;
import person.Person;

public class Talk  extends Thread  {
	private Socket client = null;
	//存储当前所有在线用户列表
	private static Map<String, Socket> clients = new HashMap<>();
	
	private BufferedReader reader = null;
    private PrintWriter writer = null;
    
	public Talk(Socket client){
		this.client = client;
	}
		@SuppressWarnings("finally")
		public void run() {
			if( this.client == null || this.client.isClosed() ){
				return;
			}
	
			BufferedReader reader = null;
			PrintWriter writer = null;
			Customer cust =new Customer();
			Cart cart=null;
			try {
				reader = new BufferedReader(new InputStreamReader(client.getInputStream()));
			
		
					exit:while( true ){
						synchronized (this) {
					String msg;
					msg = reader.readLine();
					if( msg == null ){
						break;
					}
					//阻塞等待客户端连接          
					String m [] = msg.split("@#@");			
					//search@#@1
					String result = "error";
					switch( m[0] ){
						case "login":
							int a=new Login().login(m[1], m[2]);
							
							String filepath="d:/store/online/";
					         File files = new File(filepath);
					         String[] filelist1 = files.list();
							 for (int i = 0; i < filelist1.length; i++) {
							       //遍历文件夹得到所有的在线人数
								  File readfile = new File(filepath + "\\" + filelist1[i]);
								  if(readfile.getName().equals(m[1]+".dat")){
									  result= "used";
									  break ;
								  }
			  
						      }
							if(result.equals("used")){
								break;
							}else{
								//如果该用户不在线就可以登录
								Person per=new Customer();
								per.setName(m[1]);
								per.setPassword(m[2]);
								ObjectStream.write("/online/"+per.getName()+ ".dat",per );
								if( a==0){
									result = "success@welcome "+m[1]+" login ";
									clients.put(m[1], client);
									break;
								} else if(a==1){
									result = "error@userpassword is warning!";
								}else if(a==2){
									result ="error@user is not exit!";
								}
							}		
							break;
						case "search":
							result =new Search().search(m[1]);
							break;
						case "register":
								try {
									boolean flag=new Register().register(m[1], m[2]);
									if(flag==true){
										result="success@rigister success, return login";
									}else{
										result="error@rigister error";
									}
								} catch (Exception e) {
									
									e.printStackTrace();
								}
							break;
						case "logout":
							//用户下线
							clients.remove(m[1]);
							File file=new File("D:/store/online/"+m[1]+".dat");
							if (file.exists()) {
								file.delete();			
							}
							break exit;
						case "show":
								result =new Show().show();
								break;
						case "cart"	: 
							//远程购物车操作
							try{
								ObjectInputStream in = new ObjectInputStream( 		 
								new FileInputStream("d:/store/cart/"+m[2]+ ".dat"));
								cart=(Cart)in.readObject();  
					          	in.close();
					          }catch(FileNotFoundException e){
					        	  //如果用户第一次购物，则创建新的购物车
					        	  cart=new Cart();
					          } finally{
								switch( m[1] ){
								case "add":
								    Goods gs;
								    gs=ObjectStream.read(Goods.class,"/goods/"+m[3]+".dat");
									result=cart.add(gs,m[4]);
								break;
								case "buycar":
									result=cart.show();
									break;
								case "delete":					 
									int id=Integer.parseInt(m[3]);
									result=cart.remove(id);
									break;
								case "num":
									result=cart.num();
									break;
								case "buy":
									Map<Goods, Integer> map=cart.buy();
									for (Entry<Goods, Integer> entry : map.entrySet()) {
										gs=entry.getKey();		
									    gs=ObjectStream.read(Goods.class,"/goods/"+gs.getId()+".dat");
									    //如果购买数量小于库存量则购买成功
									    if(gs.getInventory()>=entry.getValue()){
										    gs.setInventory(gs.getInventory()-entry.getValue());
										    ObjectStream.write("/goods/"+gs.getId()+ ".dat", gs);								    
										    result="购买成功";
									    }else{
									    	result="购买失败";
									    }
									}
									break;
									}	
								ObjectOutputStream out = new ObjectOutputStream( 		 
									new FileOutputStream("d:/store/cart/"+m[2]+ ".dat"));
									out.writeObject(cart);  
						          	out.close();
							break;
					  }
					}
						
					    writer = new PrintWriter(client.getOutputStream(), true);
						writer.println( result );
						}
					}
					} catch (IOException e) {
						e.printStackTrace();
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						//close
						try {
							if( writer != null )writer.close();
							if( reader != null )reader.close(); 
							if( client != null && client.isConnected() ) client.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				
				
			
			
		}
		private void broadcast(String msg){
			Set<Map.Entry<String, Socket>> entries = clients.entrySet();
			for(Map.Entry<String, Socket> entry : entries){
				send(entry.getValue(), msg);
			}
		}
		
		private void send(Socket client, String msg){
			try {
				new PrintWriter(client.getOutputStream(), true).println(msg);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		public static  Map<String, Socket> getClients(){
			return clients;
		}

	}


