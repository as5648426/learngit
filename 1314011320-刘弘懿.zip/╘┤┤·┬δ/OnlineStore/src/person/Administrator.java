package person;

public class Administrator extends Person {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4224368547452003754L;

}
