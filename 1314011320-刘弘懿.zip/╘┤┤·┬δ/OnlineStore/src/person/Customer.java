package person;


import java.io.Serializable;
import cn.edu.nuc.onlinestore.model.Cart;

public class Customer extends Person implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 548340004506237661L;

}
