package operater;

import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class ObjectStream {
	
	private final static String BASE_PATH = "d:/store/";
	
	public static boolean write(String path, Serializable obj){
		try
		{
			FileOutputStream fos = new FileOutputStream(BASE_PATH + path);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
		
			
			oos.writeObject(obj);
			fos.close();
			oos.close();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@SuppressWarnings("unchecked")
	public static <T extends Serializable> T read(Class<T> clazz, String path) throws Exception{
		

				FileInputStream fis = new FileInputStream(BASE_PATH + path);
				ObjectInputStream ois = new ObjectInputStream(fis);
		
				T t=(T)ois.readObject();
				fis.close();
				ois.close();
			return t;

	}

}