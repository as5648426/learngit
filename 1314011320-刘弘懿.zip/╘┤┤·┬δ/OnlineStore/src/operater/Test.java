package operater;
import java.io.File;



public class Test {
	
    public Test(){
    	File file=new File("d:/store/cart");
        if(!file.exists()){
        	 file.mkdirs();	
   	     }     
        File file1=new File("d:/store/user");
        
        if(!file1.exists()){
        	file1.mkdirs();
        }
        File file2=new File("d:/store/adm");
        
        if(!file2.exists()){
        	file2.mkdirs();
        }
        File file3=new File("d:/store/goods");
        
        if(!file3.exists()){
        	file3.mkdirs();
        }
        File file4=new File("d:/store/online");
        
        if(!file4.exists()){
        	file4.mkdirs();
        }
    }
}

