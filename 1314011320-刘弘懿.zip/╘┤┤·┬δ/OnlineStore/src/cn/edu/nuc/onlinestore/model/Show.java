package cn.edu.nuc.onlinestore.model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import operater.ObjectStream;

public class Show {
	TreeMap<Integer,Goods> maps =new TreeMap<Integer, Goods>();
	public String show(){
		try { 
			 ArrayList<Object> list = new ArrayList<Object>();
		     Goods gs;	
		     String filepath="d:/store/goods/";
	         File file = new File(filepath);
	         String[] filelist = file.list();
	     
	         if(filelist.length==0){
	        	System.out.println("商店无商品");
	           return "商店无商品";
	         }else{
 			     for (int i = 0; i < filelist.length; i++) {
		         File readfile = new File(filepath + "\\" + filelist[i]);
		         gs=ObjectStream.read(Goods.class,"/goods/"+readfile.getName());
		         maps.put(gs.getId(), gs);
 			    }
 			    //遍历maps取出搜索到的商品信息，转换车字符串，打包进list表
 	 			   for (Entry<Integer, Goods> entry : maps.entrySet()) {  
 						gs=entry.getValue();
 						String g="@"+gs.getId()+"@"+gs.getName()+"@"+gs.getPrice()+"@"+gs.getInventory()+"@"+gs.getIntro()+"@";
 				        list.add(g);
 	 			   }
 	 			   //清空本次搜索信息
 	 			   maps.clear();
 	 			   //将搜索到的信息返回客户端
 	 			   String s = list.toString();
 				   return s;
 			     
 			  
	         	}
	         } catch (Exception e1) {      	
	       }
		return "";
	}
}
