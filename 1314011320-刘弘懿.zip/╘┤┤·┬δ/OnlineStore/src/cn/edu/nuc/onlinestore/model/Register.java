package cn.edu.nuc.onlinestore.model;

import java.awt.Cursor;
import java.io.FileNotFoundException;
import java.sql.PseudoColumnUsage;
import java.util.Scanner;

import operater.ObjectStream;
import person.Customer;
import person.Person;

public class Register extends Customer{

		
	public  static boolean register(String username,String password) throws Exception{
		Person per =new Customer();
		per.setName(username);
		try{
			
			per= ObjectStream.read(Person.class, "/user/"+per.getName()+".dat");	
			System.out.println("该用户已被注册，请重新注册");
			return false;
		}catch (FileNotFoundException  e){
			    per.setName(username);
				per.setPassword(password);
				ObjectStream.write("/user/" +per.getName() + ".dat", per);
				System.out.println("注册成功，返回登陆界面");
				return true;
			
		}
	}
}

		
	

