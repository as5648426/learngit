package cn.edu.nuc.onlinestore.model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import operater.ObjectStream;

public class Search {
	TreeMap<Object,Object> map =new TreeMap<Object, Object>();
	TreeMap<Integer,Goods> maps =new TreeMap<Integer, Goods>();
	public String search(String search){
		 ArrayList<Object> list = new ArrayList<Object>();
		try { 
			
		     Goods gs;	
		     String filepath="d:/store/goods/";
	         File file = new File(filepath);
	         String[] filelist = file.list();
	     
	         if(filelist.length==0){
	        	System.out.println("商店无商品");
	           return "商店无商品";
	         }else{
 			     for (int i = 0; i < filelist.length; i++) {
		         File readfile = new File(filepath + "\\" + filelist[i]);
		         gs=ObjectStream.read(Goods.class,"/goods/"+readfile.getName());
				 System.out.println("商品名："+gs.getName()+" 价格:"+gs.getPrice()+" 库存量："+gs.getInventory()+" 商品编号:"+gs.getId());
				//将商品id和名字传入map里
				 map.put(gs.getId(), gs.getName());
				 if(String.valueOf(gs.getId()).indexOf(search)!=-1){
					 maps.put(gs.getId(), gs); 
				 }
 			    }
 			     //模糊搜索 去重复   将商品加入maps
 			    for(Entry<Object,Object> entry:map.entrySet()){ 
					if(String.valueOf(entry.getValue()).indexOf(search)!=-1){
						for(Object obj:getKeys(String.valueOf(entry.getValue()))){ 		
							gs=ObjectStream.read(Goods.class,"/goods/"+obj+".dat");
							maps.put(gs.getId(),gs); 
						}
						
					}
				}
 			    //遍历maps取出搜索到的商品信息，转换车字符串，打包进list表
 			   for (Entry<Integer, Goods> entry : maps.entrySet()) {  
					gs=entry.getValue();
					String g="@"+gs.getId()+"@"+gs.getName()+"@"+gs.getPrice()+"@"+gs.getInventory()+"@"+gs.getIntro()+"@";
			        list.add(g);
 			   }
 			   
 			   //清空本次搜索信息
 			   maps.clear();
 			   //将搜索到的信息返回客户端
 			   String s = list.toString();
			   return s;
	         }
	         } catch (Exception e1) {  
	        	return "找不到你要的宝贝"; 
	       }


		}
		//通过value获取map的键值
	 public List<Object> getKeys(Object value){  
	        ArrayList<Object> keys=new ArrayList<Object>();  
	        for(Entry<Object,Object> entry:map.entrySet()){  
	            if(value.equals(entry.getValue())){  
	                keys.add(entry.getKey());  
	            }else{  
	                continue;  
	            }  
	        }  
	        return keys;  
	    }  
}