package cn.edu.nuc.onlinestore.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import cn.edu.nuc.onlinestore.model.Goods;
import operater.ObjectStream;
import person.Administrator;
import person.Person;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class AdminAdd extends JFrame {

	private JPanel contentPane;
	private JTextField name;
	private JTextField price;
	private JTextField Inventory;

	/**
	 * Launch the application.
	 */
	/**
	 * Create the frame.
	 */
	public AdminAdd(Person per,DefaultTableModel model) {
		setTitle("添加商品 --操作人员:"+per.getName());
		setIconImage((Toolkit.getDefaultToolkit().getImage(AdminAdd.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		// 得到用户屏幕大小
		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -450)/2;
		y=(size.height -405)/2;
		setSize(450,405);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("商品名称:");
		label.setBounds(35, 57, 67, 15);
		contentPane.add(label);
		
		name = new JTextField();
		name.setBounds(99, 54, 269, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		JLabel label_1 = new JLabel("单价:");
		label_1.setBounds(35, 100, 54, 15);
		contentPane.add(label_1);
		
		price = new JTextField();
		price.setBounds(99, 97, 212, 21);
		contentPane.add(price);
		price.setColumns(10);
		
		JLabel label_2 = new JLabel("单位:元");
		label_2.setBounds(321, 100, 54, 15);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("数量:");
		label_3.setBounds(35, 143, 54, 15);
		contentPane.add(label_3);
		
		Inventory= new JTextField();
		Inventory.setBounds(99, 140, 269, 21);
		contentPane.add(Inventory);
		Inventory.setColumns(10);
		
		JLabel label_4 = new JLabel("简介:");
		label_4.setBounds(35, 188, 54, 15);
		contentPane.add(label_4);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(99, 184, 269, 103);
		contentPane.add(textArea);
		
		JButton add = new JButton("确定添加");
		add.setBounds(275, 310, 93, 23);
		contentPane.add(add);
		
		
		add.addActionListener(new ActionListener() {	
		@Override
			public void actionPerformed(ActionEvent e) {	
				try{
						TreeMap<Integer,Goods> maps =new TreeMap<Integer, Goods>();	
						List<Integer> list=new ArrayList();
						Goods gs;
					    String filepath="d:/store/goods/";
				        File file = new File(filepath);
				        String[] filelist = file.list(); 
				        for(int i=0;i<filelist.length;i++){
				        	File readfile = new File("d:/store/goods/"+ "\\" + filelist[i]);
				        	gs=ObjectStream.read(Goods.class,"/goods/"+readfile.getName());
				        	maps.put(gs.getId(),gs);
				        }
				        //文件重排序,获取最大的商品id，保持自增长
				        for (Entry<Integer, Goods> entry : maps.entrySet()) {  
				        	 gs=entry.getValue();
				        	 list.add(gs.getId());
				         }
			    	    int id=list.get(filelist.length-1);
			    	    //添加新商品
					    gs=new Goods();
				    	gs.setName(name.getText());
					    gs.setPrice(Integer.parseInt(price.getText()));
				        gs.setInventory(Integer.parseInt(Inventory.getText()));
				        gs.setIntro(textArea.getText());
				        gs.setId(id+1);   
						ObjectStream.write("/goods/"+gs.getId()+ ".dat", gs);
						} catch (Exception e1) {
		
					}
				}
		});
		
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				((AdminAdd)e.getSource()).setVisible(false);
			}
		});
	}
}
