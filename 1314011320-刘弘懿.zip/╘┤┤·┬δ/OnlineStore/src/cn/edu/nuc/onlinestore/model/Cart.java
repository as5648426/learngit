package cn.edu.nuc.onlinestore.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import operater.ObjectStream;

public class Cart<E> implements Serializable {
	
	private static final long serialVersionUID = -5523647580332725112L;
	
	
	private Map<Goods, Integer> maps = new HashMap<>();
	
	//购物车商品总价格
	private int totalPrice = 0;
	//购物车商品总数量
	private int totalQuantity = 0;
	
	
	/**
	 * 添加商品到购物车
	 * @param goods
	 * @param quantity
	 * @return 返回该商品在购物车内总数量
	 */
	public String add(Goods gs, String quantity){
		
		int num =Integer.parseInt(quantity);
		try {	
			if( maps.get(gs)==null ){
				//如果maps 里没有该商品,直接添加
				maps.put(gs, num);		
			} else {
				//如果maps 里已存在当前添加商品,则累加商品数量
				int a =maps.get(gs);
				maps.put(gs,num+a);
			}	
			//添加商品后调用计算购物车总金额、总价格方法
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "添加成功";
	}

	/**
	 * 根据商品id将商品从购物车内移除
	 * @param gid
	 * @return
	 */
	public String remove(int gid){
		Goods gs= new Goods();
		gs.setGid(gid);
		maps.remove(gs);
		total();
		return "删除成功";
	}
	
	/**
	 * 计算购物车总金额、总数量方法
	 */
	private void total(){
		//先将总金额、总数量归零
		this.totalPrice = 0;
		this.totalQuantity = 0;
		Goods gs;
		for (Entry<Goods, Integer> entry : maps.entrySet()) {  	
			
			 int b= this.totalQuantity;
			 int a = entry.getValue();  
			 this.totalQuantity=a+b;
			 int c= this.totalPrice;
			 gs=entry.getKey();
			 this.totalPrice=a*gs.getPrice()+c;
			}  
		
		//遍历购物车 maps 重新计算购物车总价格、总数量
		//代码省略....
	}

	/**
	 * 返回购物车商品总金额(此处不应提供set方法,因为修改购物车商品金额不能由外面修改)
	 * @return
	 */
	public double getTotalPrice() {
		return totalPrice;
	}

	/**
	 * 返回购物车商品总数量(此处不应提供set方法,因为修改购物车商品数量不能由外面修改)
	 * @return
	 */
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public String num(){
		//获取购物车数量
		total();
		String s=String.valueOf(this.totalQuantity);
		return s;
	}
	public String show(){
		Goods gs;
	    ArrayList<Object> list = new ArrayList<Object>();	
		total();
				//返回字符串		
		for (Entry<Goods, Integer> entry : maps.entrySet()) {  	
					
			gs=entry.getKey();
			int number=entry.getValue();
			int zjg=number*gs.getPrice();
		    String g="@"+gs.getId()+"@"+gs.getName()+"@"+gs.getPrice()+"@"+number+"@"+zjg+"@";
		    list.add(g);
			}  

			list.add(this.totalQuantity);
			list.add(this.totalPrice);
			String s=list.toString();	
			if (maps.isEmpty()==true){
			return "购物车为空";
			}else{
				return s;
			}
	}

	public  Map<Goods, Integer> buy() {
	    Map<Goods, Integer> map = new HashMap<>();
	    map.putAll(maps);
		maps.clear();
		return map;
	}
}
