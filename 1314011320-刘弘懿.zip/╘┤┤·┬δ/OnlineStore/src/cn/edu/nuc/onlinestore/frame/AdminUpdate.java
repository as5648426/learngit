package cn.edu.nuc.onlinestore.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cn.edu.nuc.onlinestore.model.Goods;
import operater.ObjectStream;
import person.Person;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class AdminUpdate extends JFrame {

	private JPanel contentPane;
	private JTextField name;
	private JTextField price;
	private JTextField inventory;
	private JTextField gsid;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public AdminUpdate(Person per) {
		setTitle("修改商品 ---操作人员："+per.getName());
		setIconImage((Toolkit.getDefaultToolkit().getImage(AdminUpdate.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		// 得到用户屏幕大小
		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -450)/2;
		y=(size.height -405)/2;
		setSize(450,405);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("商品名称:");
		label.setBounds(23, 57, 66, 15);
		contentPane.add(label);
		
		name = new JTextField();
		name.setBounds(99, 54, 269, 21);
		contentPane.add(name);
		name.setColumns(10);
		
		JLabel label_1 = new JLabel("单价:");
		label_1.setBounds(35, 100, 54, 15);
		contentPane.add(label_1);
		
		price = new JTextField();
		price.setBounds(99, 97, 212, 21);
		contentPane.add(price);
		price.setColumns(10);
		
		JLabel label_2 = new JLabel("单位:元");
		label_2.setBounds(321, 100, 54, 15);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("数量:");
		label_3.setBounds(35, 143, 54, 15);
		contentPane.add(label_3);
		
		inventory = new JTextField();
		inventory.setBounds(99, 140, 212, 21);
		contentPane.add(inventory);
		inventory.setColumns(10);
		
		JLabel label_4 = new JLabel("简介:");
		label_4.setBounds(35, 188, 54, 15);
		contentPane.add(label_4);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(99, 184, 269, 103);
		contentPane.add(textArea);
		
		JButton modify = new JButton("确定修改");
		modify.setBounds(275, 310, 93, 23);
		contentPane.add(modify);
		
		
		JLabel label_5 = new JLabel(">=0");
		label_5.setBounds(321, 143, 43, 15);
		contentPane.add(label_5);
		
		JLabel id = new JLabel("商品编号:");
		id.setBounds(23, 21, 66, 15);
		contentPane.add(id);
		
		gsid = new JTextField();
		gsid.setBounds(99, 18, 157, 21);
		contentPane.add(gsid);
		gsid.setColumns(10);
		
		modify.addActionListener(new ActionListener() {	
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			Goods gs=new Goods();
			try {
				gs=ObjectStream.read(Goods.class,"/goods/"+gsid.getText()+ ".dat");
				gs.setName(name.getText());
				gs.setPrice(Integer.parseInt(price.getText()));
				gs.setIntro(textArea.getText());
				gs.setInventory(Integer.parseInt(inventory.getText()));
				ObjectStream.write("goods/"+gs.getId()+ ".dat", gs);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null,"该物品不存在，请重新输入商品ID","修改失败",JOptionPane.OK_CANCEL_OPTION);
			}
			
			}
		});
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				((AdminUpdate)e.getSource()).setVisible(false);
			}
		});
	}
}
