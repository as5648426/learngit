package cn.edu.nuc.onlinestore.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.TCPServer;
import operater.ObjectStream;
import operater.Test;
import person.Administrator;
import person.Person;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class AdminLogin extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	JFrame th =this;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
					TCPServer.start(8888);
					Test test =new Test();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param per 
	 */
	public AdminLogin() {
		setTitle("中北线在商场管理系统-管理员登录");
		setIconImage((Toolkit.getDefaultToolkit().getImage(AdminLogin.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		int x,y;
		// 得到用户屏幕大小
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -480)/2;
		y=(size.height -320)/2;
		setSize(480,320);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("用户名:");
		label.setBounds(87, 146, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("密  码:");
		label_1.setBounds(87, 185, 54, 15);
		contentPane.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(151, 146, 197, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(151, 185, 197, 21);
		contentPane.add(passwordField);
		

		JButton register= new JButton("注册账户");
		register.setBounds(150, 216, 93, 23);
		contentPane.add( register);
		
		JButton login = new JButton("登录系统");
		 login.setBounds(255, 216, 93, 23);
		contentPane.add( login);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(AdminLogin.class.getResource("/image/a.gif")));
		lblNewLabel.setBounds(174, 10, 128, 126);
		contentPane.add(lblNewLabel);
		login.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			Person per=new Administrator();
			per.setName(textField.getText());
			per.setPassword(passwordField.getText());
		//登录校验
			if(per.getName().equals("")||per.getPassword().equals("")){
				JOptionPane.showMessageDialog(null,"账号或密码不能为空","警告",JOptionPane.OK_CANCEL_OPTION);
			}else{
		//从本地读取文件判断管理员
			try {
				per=(Administrator)ObjectStream.read(Person.class, "/adm/"+per.getName()+".dat");
		
				if(per.getPassword().equals(passwordField.getText())){
					JOptionPane.showMessageDialog(null,"欢迎管理员登录购物管理系统","登陆成功",JOptionPane.OK_CANCEL_OPTION);
					textField.setText(null);
					passwordField.setText(null);
					AdminStore f=  new AdminStore(per);
					f.setVisible(true);
					th.setVisible(false);
//						
				
				}else{
					JOptionPane.showMessageDialog(null,"您的密码有误,请重新输入","警告",JOptionPane.OK_CANCEL_OPTION);
					passwordField.setText(null);
				}	
				} catch (Exception e1) {
				    JOptionPane.showMessageDialog(null,"管理员账号错误","警告",JOptionPane.OK_CANCEL_OPTION);
					textField.setText(null);
					passwordField.setText(null);
				 }
				}	
			}
		});
		register.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Person per=new Administrator();
				per.setName(textField.getText());
				per.setPassword(passwordField.getText());
				//本地校验
				if(per.getName().equals("")||per.getPassword().equals("")){
					JOptionPane.showMessageDialog(null,"账号或密码不能为空","警告",JOptionPane.OK_CANCEL_OPTION);
				}else{		
				try{		
				//判断用户名是否可注册
					per= ObjectStream.read(Person.class, "/adm/"+per.getName()+".dat");
					JOptionPane.showMessageDialog(null,"该用户已被注册，请重新注册","警告",JOptionPane.OK_CANCEL_OPTION);
					textField.setText(null);
					passwordField.setText(null);
					
				} catch (Exception e1) {
//						请输入您的密码
					ObjectStream.write("/adm/" +per.getName() + ".dat", per);
					JOptionPane.showMessageDialog(null,"注册成功","恭喜",JOptionPane.OK_CANCEL_OPTION);
					textField.setText(null);
					passwordField.setText(null);
					
					}
				}
			}
		});
		
	}
}
