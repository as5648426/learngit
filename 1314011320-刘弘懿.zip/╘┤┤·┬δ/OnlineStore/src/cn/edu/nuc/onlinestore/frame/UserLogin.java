package cn.edu.nuc.onlinestore.frame;


import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TreeMap;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.TCPClient;
import person.Customer;
import person.Person;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class UserLogin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3778738051998315929L;
	private JPanel contentPane;
	private JTextField account;
	private JPasswordField passwordField;
	 JFrame th=this;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserLogin frame = new UserLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserLogin() {
		Person per=new Customer();
		setTitle("中北商场--请用户登录");
		setIconImage((Toolkit.getDefaultToolkit().getImage(UserLogin.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));

		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -461)/2;
		y=(size.height -349)/2;
		setSize(461,349);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		@SuppressWarnings("unused")
		TreeMap<Object,Object> map =new TreeMap<Object, Object>();

		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel label = new JLabel("用户名:");
		label.setBounds(87, 146, 54, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("密  码:");
		label_1.setBounds(87, 185, 54, 15);
		contentPane.add(label_1);
		
		account = new JTextField();
		account.setBounds(151, 146, 197, 21);
		contentPane.add(account);
		account.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(151, 185, 197, 21);
		contentPane.add(passwordField);
		
		JButton login= new JButton("登录系统");
		login.setBounds(255, 216, 93, 23);
		contentPane.add(login);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(UserLogin.class.getResource("/image/u.gif")));
		lblNewLabel.setBounds(164, 10, 132, 126);
		contentPane.add(lblNewLabel);
		
		JButton register = new JButton("用户注册");
		register.setBounds(151, 216, 93, 23);
		contentPane.add(register);
		
		register.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//注册时与服务器交换消息
				String username = account.getText();
				@SuppressWarnings("deprecation")
				String password=passwordField.getText();
				String msg ="register@#@"+username+"@#@"+password;
				String result=new TCPClient().send(msg);
				String m[] =result.split("@");
				//根据返回值判断登录状态
				if(m[0].equals( result )){
					String a=m[1];
					JOptionPane.showMessageDialog(null,a);					
					//
				} else {
					String a=m[1];
					JOptionPane.showMessageDialog(null,a);
				}
				
			}
		});
		login.addActionListener(new ActionListener() {	
			@Override
			//登录时与服务器交换消息
			public void actionPerformed(ActionEvent e) {
				String username = account.getText();
				String password=passwordField.getText();
				if(username.equals("")||password.equals("")){
					JOptionPane.showMessageDialog(null,"账号或密码不能为空","警告",JOptionPane.OK_CANCEL_OPTION);
				}else{
				String msg ="login@#@"+account.getText()+"@#@"+password;
				String result=new TCPClient().send(msg);
				String m[] =result.split("@");
				//根据服务器消息判断注册状态
				if(m[0].equals("success")){
					String a=m[1];
					JOptionPane.showMessageDialog(null,a,"成功",JOptionPane.OK_CANCEL_OPTION);
					per.setName(username);
					per.setPassword(password);
					UserStore f=  new UserStore(per);
					f.setVisible(true);	
					th.setVisible(false);
				} else if(result.equals("used")){
					JOptionPane.showMessageDialog(null,"当前有人正在操作此账户","登录失败",JOptionPane.OK_CANCEL_OPTION);	
				}else {
					String a=m[1];
					JOptionPane.showMessageDialog(null,a,"失败",JOptionPane.OK_OPTION);
				}
				}
			}
		});
		
	}
}
