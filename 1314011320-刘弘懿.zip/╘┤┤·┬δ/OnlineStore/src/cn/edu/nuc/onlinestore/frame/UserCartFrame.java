package cn.edu.nuc.onlinestore.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import cn.edu.nuc.onlinestore.model.Goods;
import net.TCPClient;
import person.Person;

import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

public class UserCartFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3075440047691550991L;
	private JPanel contentPane;
	private JTable table;
	
	List<Goods> gs1=new ArrayList();

	//购物车商品总价格
	private String totalPrice ="0";
	//购物车商品总数量
	private String totalQuantity = "0"; 
	JLabel number;
	JLabel zj;;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public UserCartFrame(Person per) {
		setTitle("购物车详情");
		setIconImage((Toolkit.getDefaultToolkit().getImage(UserCartFrame.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -591)/2;
		y=(size.height -377)/2;
		setSize(591,377);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 78, 560, 200);
		panel.setLayout(new GridLayout(1, 1, 0, 0));
		
		
		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("商品编号");
		model.addColumn("名称");
		model.addColumn("单价(￥)");
		model.addColumn("数量");
		model.addColumn("总价格(￥)");
		//model.addColumn("操作");
		number = new JLabel();
		number.setBounds(10, 292, 116, 15);
		contentPane.add(number);
		
	    zj = new JLabel();
		zj.setBounds(139, 292, 211, 15);
		contentPane.add(zj);
		
		show(model,per);
		
		JButton delete = new JButton("删除");
		delete.setBounds(352, 288, 93, 23);
		contentPane.add(delete);
	
		delete.addActionListener(new ActionListener() {
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				int b=table.getSelectedRow(); 
				if(b==-1||model==null){
				JOptionPane.showMessageDialog(null,"您的购物车已为空","删除失败",JOptionPane.OK_CANCEL_OPTION);
				}else{
				String c=String.valueOf(model.getValueAt(b,0));
			    String msg ="cart@#@"+"delete@#@"+per.getName()+"@#@"+c;
				String result=new TCPClient().send(msg);			
				show(model,per);
				}
			}
		});
		
		table = new JTable( model );
		table.setBounds(10, 38, 543, 184);
		JScrollPane pane = new JScrollPane( table );
		panel.add(pane);
		contentPane.add(panel);	
		
		JButton buy = new JButton("结账");
		buy.setBounds(477, 288, 93, 23);
		contentPane.add(buy);
		buy.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String msg ="cart@#@"+"buy@#@"+per.getName()+"@#@"+"123";
				String result=new TCPClient().send(msg);				
				if(result.equals("购买成功")){
				JOptionPane.showMessageDialog(null,"感谢您使用本系统完成本次购物","友情提示",JOptionPane.OK_CANCEL_OPTION);
				show(model,per);
				}else if(result.equals("购买失败")){
				JOptionPane.showMessageDialog(null,"您买的商品小店供给不上，请重新看看吧","友情提示",JOptionPane.OK_CANCEL_OPTION);
					
				}else{
				
				JOptionPane.showMessageDialog(null,"购物车内空空如也，请先添加","友情提示",JOptionPane.OK_CANCEL_OPTION);
				}
			}
		});
		
	
		
	}
	public void show(DefaultTableModel model,Person per){
		this.totalPrice = "0";
		this.totalQuantity = "0";
		try { 
			int a=model.getRowCount();
			 for(int i=a-1;i>=0;i--){
		         model.removeRow(i);
		     } 
		    String msg ="cart@#@"+"buycar@#@"+per.getName()+"@#@"+"123";
			String result=new TCPClient().send(msg);
			if(result.equals("购物车为空")){
				number.setText("总商品数量:0");
			    zj.setText("总金额:0");
			
			}else if(result.equals("error")){
					
			}else{
					
			  List<String> list = Arrays.asList(result.split(","));
			  for(int i=0;i<list.size()-2;i++){  
				  	String s=list.get(i);  
				  	
					String m [] = s.split("@");
					Goods gs=new Goods();
					gs.setId(Integer.parseInt(m[1]));
					gs.setName(m[2]);
					gs.setPrice(Integer.parseInt(m[3]));
					gs.setInventory(Integer.parseInt(m[4]));
					gs.setIntro(m[5]);
					gs1.add(gs);
					model.addRow(new String[]{m[1],m[2],m[3],m[4],m[5]});			
			  	}
			    int j=list.size()-1;
			  	if(list.get(j-1)!=null){
				   j=list.size()-1;
				  this.totalPrice=list.get(j);
				  this.totalQuantity=list.get(j-1);
				  String str =this.totalPrice; 
				  this.totalPrice= str.substring(0,str.length()-1);
				  number.setText("总商品数量:"+totalQuantity);
				  zj.setText("总金额:"+totalPrice);
			  	}
			}
		} catch (Exception e1) {}
	}
}
