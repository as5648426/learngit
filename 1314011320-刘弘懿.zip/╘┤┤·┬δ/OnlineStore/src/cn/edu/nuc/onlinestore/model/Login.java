package cn.edu.nuc.onlinestore.model;



import operater.ObjectStream;

import person.Customer;
import person.Person;

public class Login extends Customer{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5486063687908198984L;

	public int login(String username,String password){
		Person per;
		try {
			//判断用户是否可以登录
			per=(Customer)ObjectStream.read(Person.class, "/user/"+username+".dat");
	
			if(password.equals(per.getPassword())){
				
				return 0;
			
			}else{
				return 1;
			}	
			} catch (Exception e1) {
			return 2;
			}
	}

}
