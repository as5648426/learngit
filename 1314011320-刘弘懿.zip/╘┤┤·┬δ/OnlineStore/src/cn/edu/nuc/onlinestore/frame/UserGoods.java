package cn.edu.nuc.onlinestore.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cn.edu.nuc.onlinestore.model.Goods;
import net.TCPClient;
import person.Person;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;

public class UserGoods extends JFrame {

	private JPanel contentPane;
	private JTextField number;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public UserGoods(Goods gs, Person per) {
		setTitle("商品详情");
		setIconImage((Toolkit.getDefaultToolkit().getImage(UserGoods.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -450)/2;
		y=(size.height -405)/2;
		setSize(450,405);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("商品名称:");
		label.setBounds(23, 57, 66, 15);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("单价:");
		label_1.setBounds(35, 100, 54, 15);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("单位:元");
		label_2.setBounds(321, 100, 54, 15);
		contentPane.add(label_2);
		
		JLabel label_4 = new JLabel("简介:");
		label_4.setBounds(35, 141, 44, 46);
		contentPane.add(label_4);
		
		JButton add = new JButton("加入购物车");
		add.setBounds(175, 243, 126, 23);
		contentPane.add(add);
		
		
		
		JLabel name = new JLabel(gs.getName());
		name.setBounds(99, 57, 162, 15);
		contentPane.add(name);
		
		JLabel price = new JLabel(String.valueOf(gs.getPrice()));
		price.setBounds(99, 100, 145, 15);
		contentPane.add(price);
		
		JLabel intro = new JLabel(gs.getIntro());
		intro.setBounds(99, 141, 251, 46);
		contentPane.add(intro);
		
		number = new JTextField();
		number.setText("1");
		number.setBounds(99, 244, 66, 21);
		contentPane.add(number);
		number.setColumns(10);
		
		JLabel buy = new JLabel("购买数量:");
		buy.setBounds(35, 247, 71, 15);
		contentPane.add(buy);
		
		JLabel inventory= new JLabel("库存:"+String.valueOf(gs.getInventory()));
		inventory.setBounds(99, 273, 135, 15);
		contentPane.add(inventory);
		add.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String name=per.getName();
				//如果购买数量小于库存量则添加成功
				if(gs.getInventory()>=Integer.parseInt(number.getText())){
				String id =String.valueOf(gs.getId());
				String msg ="cart@#@"+"add@#@"+name+"@#@"+id+"@#@"+number.getText();
				String result=new TCPClient().send(msg);
				}else{
					//添加失败
				JOptionPane.showMessageDialog(null,"您买的商品 数量已不足请重新选择","友情提示",JOptionPane.OK_CANCEL_OPTION);
				}
			}
		});
		
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				((UserGoods)e.getSource()).setVisible(false);
			}
		});
	}
}
