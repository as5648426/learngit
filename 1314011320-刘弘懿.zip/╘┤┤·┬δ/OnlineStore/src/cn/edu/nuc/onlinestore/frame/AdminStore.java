package cn.edu.nuc.onlinestore.frame;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import cn.edu.nuc.onlinestore.model.Goods;
import net.TCPClient;
import net.TCPServer;
//import net.TCPServer;
import operater.ObjectStream;
import person.Administrator;
import person.Person;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;  
import java.util.Map.Entry;
import java.util.TreeMap;
import java.awt.event.ActionEvent;

public class AdminStore extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5585734323922548650L;
	private JPanel contentPane;
	private JTextField textField;
	private JTable table;
	private TCPServer server=null;
	TreeMap<Object,Object> map =new TreeMap<Object, Object>();
	TreeMap<Integer,Goods> maps =new TreeMap<Integer, Goods>();
	TreeMap<Integer,Goods> map1 =new TreeMap<Integer, Goods>();
	JLabel online;
	JFrame th=this;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public AdminStore(Person per) {
		//启动服务器
		
     	setTitle("中北商场后台管理系统--当前管理员:"+per.getName());
     	setIconImage((Toolkit.getDefaultToolkit().getImage(AdminStore.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		// 得到用户屏幕大小
		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -732)/2;
		y=(size.height -467)/2;
		setSize(732,467);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 78, 696, 341);
		panel.setLayout(new GridLayout(1, 1, 0, 0));
	
		//model.addColumn("操作");
		DefaultTableModel model = new DefaultTableModel(){
			public boolean isCellEditable(int row, int column) {
				return false;
				}
		};
		model.addColumn("商品编号");
		model.addColumn("名称");
		model.addColumn("单价(人民币)");
		model.addColumn("库存");
		
		online = new JLabel("当前在线用户数:0");
		online.setBounds(10, 10, 162, 15);
		contentPane.add(online);
		
		show(model,per);     
		JButton show1 = new JButton("刷新列表");
		show1.setBounds(489, 12, 93, 23);
		contentPane.add(show1);
	
	    show1.addActionListener(new ActionListener() {  	
			@Override
			public void actionPerformed(ActionEvent e) {
				show(model,per);
				
			}
		});
	
	    JButton button_2 = new JButton("删除选中商品");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Goods gs;
				//得到当前选中商品项
				int[] selected = table.getSelectedRows();
				// 一次删除所有选中行
				for (int i=selected.length-1 ;i>=0;i--) {
				try {
				
					int a=selected[i]+1;
					String b=String.valueOf(model.getValueAt(selected[i], 0));				
					gs=ObjectStream.read(Goods.class,"/goods/"+Integer.parseInt(b)+".dat");
					int j=JOptionPane.showConfirmDialog(null, "确定要删除"+gs.getName()+"么","提示", JOptionPane.YES_NO_OPTION);
					map.remove(a);
					
					File file=new File("D:/store/goods/"+gs.getId()+".dat");
					if (file.exists()) {
						file.delete();
						if(j==0){
						model.removeRow(selected[i]);
						}
					}
				  } catch (Exception e1) {
					
					e1.printStackTrace();
				
				 }
				}
				show(model,per);
			}
		});
		JButton search = new JButton("搜索");
		search.setBounds(180, 49, 93, 23);
		contentPane.add(search);
		
		search.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			try { 
			
				Goods gs;	
			    String s=textField.getText();	
			    //清空现有列表
			    int a=model.getRowCount();			
				for(int i=a-1;i>=0;i--){
	                 model.removeRow(i);
	             } 
				//从map中取出模糊搜索到的商品，转换成id名字读取文件
			    for(Entry<Object,Object> entry:map.entrySet()){ 
					if(String.valueOf(entry.getValue()).indexOf(s)!=-1){
						for(Object obj:getKeys(String.valueOf(entry.getValue()))){ 		
							gs=ObjectStream.read(Goods.class,"/goods/"+obj+".dat");
							maps.put(gs.getId(),gs);
						}			
					}
					//通过商品id模糊搜索
					if(String.valueOf(entry.getKey()).indexOf(s)!=-1){
						gs=ObjectStream.read(Goods.class,"/goods/"+entry.getKey()+".dat");
						maps.put(gs.getId(),gs);
					}
				}
			    //取出商品信息，显示
				for (Entry<Integer, Goods> entry : maps.entrySet()) {  
						gs=entry.getValue();
						model.addRow(new String[]{String.valueOf(gs.getId()),gs.getName(),String.valueOf(gs.getPrice()),String.valueOf(gs.getInventory())});
				}
				maps.clear();
			  } catch (Exception e1) {       	
	       }
				
		}
		//map通过value 来返回其key值
		 public List<Object> getKeys(Object value){  
		        ArrayList<Object> keys=new ArrayList<Object>();  
		        for(Entry<Object,Object> entry:map.entrySet()){  
		            if(value.equals(entry.getValue())){  
		                keys.add(entry.getKey());  
		            }else{  
		                continue;  
		            }  
		        }  
		        return keys;  
		    }  
		});

		
		JButton button = new JButton("添加商品");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminAdd add = new AdminAdd(per,model);
				add.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				add.setVisible(true);
			
			}
		});
		button.setBounds(386, 45, 93, 23);
		contentPane.add(button);
		
		JButton button_1 = new JButton("修改商品");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminUpdate u = new AdminUpdate(per);
				u.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				u.setVisible(true);
			}
		});
		
		button_1.setBounds(489, 45, 93, 23);
		contentPane.add(button_1);
	
		
		button_2.setBounds(587, 45, 119, 23);
		contentPane.add(button_2);
		
		JButton exit = new JButton("退出登录");
		exit.setBounds(601, 12, 93, 23);
		contentPane.add(exit);
		
		
		JLabel lblid = new JLabel("商品名字:");
		lblid.setBounds(10, 53, 66, 15);
		contentPane.add(lblid);
		
		textField = new JTextField();
		textField.setBounds(68, 50, 104, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		table = new JTable( model );
		JScrollPane pane = new JScrollPane( table );
		panel.add(pane);
		contentPane.add(panel);
		
		
		exit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Person per= null;
				AdminLogin f=  new AdminLogin();
				f.setVisible(true);
				th.setVisible(false);
			}
		});
		
	}
	public void show(DefaultTableModel model,Person per){
	 
		int a=model.getRowCount();
		 for(int i=a-1;i>=0;i--){
             model.removeRow(i);
         }    
		 //统计在线人数
		   String path="d:/store/online/";
	         File on = new File(path);
	         int s=on.list().length;
	         online.setText("当前在线用户数:"+s);
		 Goods gs;
	     String filepath="d:/store/goods/";
         File file = new File(filepath);
         String[] filelist = file.list();
         
         if(filelist.length==0){
            int n =JOptionPane.showConfirmDialog(null,"商店为空，是否马上添加商品","警告",JOptionPane.YES_NO_OPTION);
 			if(n==0){
 				//跳转到添加商品界面
 				AdminAdd add = new AdminAdd(per,model);
 				add.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
 				add.setVisible(true);
 			}
         }else{
        	 map.clear();
	         for (int i = 0; i < filelist.length; i++) {
	       //遍历文件夹得到所有的商品
		         File readfile = new File(filepath + "\\" + filelist[i]);
		         try {
					gs=ObjectStream.read(Goods.class,"/goods/"+readfile.getName());
					 map.put(gs.getId(), gs.getName());
					 map1.put(gs.getId(),gs);
				//将商品id和名字传入map里
				} catch (Exception e) {
					e.printStackTrace();
				}   
	         }	
	       //重新排序
	         for (Entry<Integer, Goods> entry : map1.entrySet()) {  
	        	 gs=entry.getValue();
	        	 model.addRow(new String[]{String.valueOf(gs.getId()),gs.getName(),String.valueOf(gs.getPrice()),String.valueOf(gs.getInventory())});
	         }
	         map1.clear();
         	}
	}
}

