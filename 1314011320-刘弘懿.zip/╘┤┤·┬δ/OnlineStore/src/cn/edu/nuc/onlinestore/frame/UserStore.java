package cn.edu.nuc.onlinestore.frame;


import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;


import cn.edu.nuc.onlinestore.model.Goods;
import net.TCPClient;

import person.Person;


import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.GridLayout;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Arrays;

import java.util.List;
import java.util.TreeMap;

import java.awt.event.ActionEvent;

public class UserStore extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4169264676683455494L;
	private JPanel contentPane;
	private JTextField textField;
	@SuppressWarnings("unused")
	private JTable table;	
	JFrame th=this;
	JLabel number;
	List<Goods> gs1=new ArrayList();
	List<Goods> gs2=new ArrayList();
	
	
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public UserStore(Person per) {
		setTitle("中北商场--当前用户:"+per.getName());
		setIconImage((Toolkit.getDefaultToolkit().getImage(UserStore.class.getResource("/image/78`J%~MEC9XCL}[KM)ZL1JL.png"))));
		int x,y;
		Dimension size=Toolkit.getDefaultToolkit().getScreenSize();
		x=(size.width -732)/2;
		y=(size.height -467)/2;
		setSize(732,467);
		setLocation(x, y);
		setMinimumSize(new Dimension(250,150));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		TreeMap<Object,Object> map =new TreeMap<Object, Object>();
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 78, 696, 341);
		panel.setLayout(new GridLayout(1, 1, 0, 0));
		
		DefaultTableModel model = new DefaultTableModel(){
			public boolean isCellEditable(int row, int column) {
				return false;
				}
			
		};
		model.addColumn("商品编号");
		model.addColumn("名称");
		model.addColumn("单价(人民币)");
		model.addColumn("库存");
		number = new JLabel("购物车: 0件商品");
		number.setBounds(10, 10, 124, 15);
		contentPane.add(number);
		//model.addColumn("操作");
		//展示所有商品		
		show(model, per);		

		JButton show = new JButton("刷新列表");
		show.setBounds(510, 6, 93, 23);
		contentPane.add(show);
		
		 show.addActionListener(new ActionListener() {
			 
		    	
			@Override
			public void actionPerformed(ActionEvent e) {
				show(model, per);
					
			}
		});
	    JButton search = new JButton("搜索");
		search.setBounds(197, 45, 93, 23);
		contentPane.add(search);
		search.addActionListener(new ActionListener() {
			
		@Override
		public void actionPerformed(ActionEvent e) {
			 int a=model.getRowCount();	 
	   		 for(int i=a-1;i>=0;i--){
                 model.removeRow(i);
	        } 
			gs2.addAll(gs1);
			gs1.removeAll(gs2); 
			String name =per.getName();
			String msg ="search@#@"+textField.getText()+"@#@"+name;
			String result=new TCPClient().send(msg);	
			if(result.equals("找不到你要的宝贝")){
				JOptionPane.showMessageDialog(null,"找不到你要的宝贝","大侠尽力了",JOptionPane.OK_CANCEL_OPTION);
			}else if(result.equals("")){
				
			}else{
				
			  List<String> list = Arrays.asList(result.split(","));
		      for(Object obj : list){
		    	  //得出商品信息
					String m [] = ((String) obj).split("@");
					Goods gs=new Goods();
					gs.setId(Integer.parseInt(m[1]));
					gs.setName(m[2]);
					gs.setPrice(Integer.parseInt(m[3]));
					gs.setInventory(Integer.parseInt(m[4]));
					gs.setIntro(m[5]);
					gs1.add(gs);
					model.addRow(new String[]{m[1],m[2],m[3],m[4],m[5]});			
				}                
               }  
			}
		});
		
		JTable table = new JTable( model );
	
		JScrollPane pane = new JScrollPane( table );
		
		panel.add(pane);
		contentPane.add(panel);
		
		JButton button_2 = new JButton("查看商品详细信息(或双单击商品列)");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a =table.getSelectedRow();
				if(a!=-1){
					Goods gs;	 
					gs=gs1.get(a);
					UserGoods d = new UserGoods(gs,per);
					d.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
					d.setVisible(true);
				}else{
					JOptionPane.showMessageDialog(null,"请选择商品后查看","警告",JOptionPane.OK_CANCEL_OPTION);
				}
			}
		});
		button_2.setBounds(407, 45, 299, 23);
		contentPane.add(button_2);
		
		JButton button_3 = new JButton("退出登录");
		button_3.setBounds(613, 6, 93, 23);
		contentPane.add(button_3);
		
		button_3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		//退出登录消息，服务器将释放用户信息
		  String msg ="logout@#@"+per.getName()+"@#@"+"bye"+"@#@";	
		  String result=new TCPClient().send(msg);  
			UserLogin f=  new UserLogin();
			f.setVisible(true);
			th.setVisible(false);
			}
		});
		
		JLabel lblid = new JLabel("商品名称:");
		lblid.setBounds(10, 53, 65, 15);
		contentPane.add(lblid);
		
		textField = new JTextField();
		textField.setBounds(85, 46, 104, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				//关闭窗口则下线
				  String msg ="logout@#@"+per.getName()+"@#@"+"bye"+"@#@";	
				  String result=new TCPClient().send(msg);  
			}
		});
		
		
		JButton button_5 = new JButton("查看购物车");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				UserCartFrame cf = new UserCartFrame(per);
				cf.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
				cf.setVisible(true);
			}
		});
		button_5.setBounds(116, 6, 110, 23);
		contentPane.add(button_5);
		th.setVisible(true);
		
		 table.addMouseListener(new MouseAdapter(){ 

		    public void mouseClicked(MouseEvent e){ 
		       if(e.getClickCount() == 2){
		    	   int row =((JTable)e.getSource()).rowAtPoint(e.getPoint()); //获得行位置 
			   		if(row!=-1){
						Goods gs;	 
						gs=gs1.get(row);
						UserGoods d = new UserGoods(gs,per);
						d.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
						d.setVisible(true);
		   		} else{
		       		return;
		       		}
		       	}
		      }
		 });

	}
	public void show(DefaultTableModel model,Person per){
		int a=model.getRowCount();
		//清空当前列表
		 for(int i=a-1;i>=0;i--){
            model.removeRow(i);
        }    
		gs2.addAll(gs1);
		gs1.removeAll(gs2);
	    String msg ="show@#@"+"adm"+"@#@";
		String result=new TCPClient().send(msg);
		
		if(result.equals("商店无商品")){
			
		}else if(result.equals("error")){
			
		}else{
		//返回购物车数量
		  String msg1 ="cart@#@"+"num"+"@#@"+per.getName()+"@#@";	
		  String result1=new TCPClient().send(msg1);  
		  number.setText("购物车: "+result1+"件商品");
		 //将商品信息解压后装进列表
		  List<String> list = Arrays.asList(result.split(","));	
	      for(Object obj : list){
				String m [] = ((String) obj).split("@");
				Goods gs=new Goods();
				gs.setId(Integer.parseInt(m[1]));
				gs.setName(m[2]);
				gs.setPrice(Integer.parseInt(m[3]));
				gs.setInventory(Integer.parseInt(m[4]));
				gs.setIntro(m[5]);
				gs1.add(gs);
				model.addRow(new String[]{m[1],m[2],m[3],m[4],m[5]});

			}  
        }  
	}
}
